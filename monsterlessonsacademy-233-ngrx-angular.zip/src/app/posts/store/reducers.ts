import { createReducer, on } from '@ngrx/store';
import { PostsStateInterface } from '../types/postsState.interface';
import * as PostsActions from './actions';

export const initialState: PostsStateInterface = {
  isLoading: false,
  posts: [],
  error: null,
  action: undefined
};

export const reducers = createReducer(
  initialState,
  on(PostsActions.getPosts, PostsActions.editPosts, (state) => ({ ...state, isLoading: true })),
  on(PostsActions.getPostsSuccess, (state, action) => ({
    ...state,
    isLoading: false,
    posts: action.posts,
    action:"get"
  })),
  on(PostsActions.getPostsFailure, (state, action) => ({
    ...state,
    isLoading: false,
    error: action.error,
  })),

  on(PostsActions.editPostsSucess, (state, action) => ({
    
    ...state,
    posts: state.posts.map((post) => {
      if (post.id === action.post.id) {
        return action.post;
      }
      return post;
    }),
    isLoading: false,
    action:"edit"
  })),

);
