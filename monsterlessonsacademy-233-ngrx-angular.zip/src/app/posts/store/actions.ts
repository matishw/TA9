import { createAction, props } from '@ngrx/store';
import { PostInterface } from '../types/post.interface';

export const getPosts = createAction('[Posts] Get Posts');





export const editPosts = createAction('[Posts] Edit Posts', props<{ post: PostInterface }>());

export const deletePosts = createAction('[Posts] Edit Posts', props<{ id: string }>());
export const getPostsSuccess = createAction(
  '[Posts] Get Posts success',
  props<{ posts: PostInterface[] }>()
);


export const editPostsSucess = createAction(
  '[Posts] edit Posts success',
  props<{ post: PostInterface}>()
);






export const getPostsFailure = createAction(
  '[Posts] Get Posts failure',
  props<{ error: string }>()
);
