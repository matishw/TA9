export interface PostInterface {
  id: string;
  title: string;
}
