import { PostInterface } from './post.interface';

export interface PostsStateInterface {
  isLoading: boolean;
  posts: PostInterface[];
  action?:string
  error: string | null;
}
