import { PostsStateInterface } from '../posts/types/postsState.interface';

export interface AppStateInterface {
  posts: PostsStateInterface;
}
